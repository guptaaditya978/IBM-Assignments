package com.ibm.trainning;

import java.util.Arrays;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;

@Service
public class UserService {
	
	@Autowired
	RestTemplate template;
	

	@HystrixCommand(fallbackMethod = "stillWorks")
	public List<Object> getUsers() {
		String anotherServiceUrl = "http://localhost:8080/index/users";
		
		Object []dataFromOtherService = template.getForObject(anotherServiceUrl, Object[].class);
		
		return Arrays.asList(dataFromOtherService);
	}
	
	
	
	public List<Object> stillWorks(){
		return Arrays.asList(
				new User(109, "Raju","9456732812", "Bombay")
		);
	}
	
}
