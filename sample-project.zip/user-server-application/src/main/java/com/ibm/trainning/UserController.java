package com.ibm.trainning;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
@RequestMapping("/index2")
public class UserController {

	@Autowired
	UserService userService;
	
	@GetMapping("/viewAll")
    List<Object> getUsers(){
        return userService.getUsers();
    }
    
//	@PostMapping("/users")
//    void addUser(@RequestBody User user) {
//		userService.addUser(user);
//    }
//     
//    @GetMapping("/users/{id}")
//    Optional<User> getUserById(@PathVariable int id) {
//        return userService.getUserById(id);
//    }
//    
//    @PutMapping("/users")
//    void updateUser(@RequestBody User user) {
//		userService.updateUser(user);
//    }
//    
//    @DeleteMapping("/users/{id}")
//    void deleteUser(@PathVariable int id) {
//		userService.deleteUser(id);
//    }
//     
////  Call our own fully customized method from the userRepo
//    @GetMapping("/users/address/{address}")
//    List<String> getNameByAddress(@PathVariable String address) {
//        return userService.getUserByName(address);
//    }
}
