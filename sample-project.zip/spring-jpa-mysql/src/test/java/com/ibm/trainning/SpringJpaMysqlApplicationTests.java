package com.ibm.trainning;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringJpaMysqlApplicationTests {

	@Test
	void contextLoads() {
	}

}
